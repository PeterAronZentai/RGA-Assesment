#RGA Assessment for Front-end Developer


###Demo1:

- calls API "//data.gov.uk/data/api/service/health/pharmacies/partial_postcode?partial_postcode=TW8"
- displays list of received pharmacy names in `<select>` element
- displays the address of chosen pharmacy

 
---

###Demo2:

- let's you append rows to table (gender with its percentage)
- let's you delete rows from the table
- total percentage cannot exceed 100%
- gender type cannot be duplicate (up to 1x male and 1x female rows)
